#!/usr/bin/env python3
"""Build a swing reel project from a config JSON.

usage: python3 build.py config.json OUT_DIR

Writes OUT_DIR/index.html (a Hyperframes composition), copies fonts and logos,
fetches gsap.min.js if missing, and writes OUT_DIR/sfx.wav (the sound design,
timed to the same scene clock). Render with Hyperframes, then mux sfx.wav in.
"""
import html, json, os, re, shutil, subprocess, sys, tarfile, wave
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
TEMPLATE = os.path.join(SKILL, 'template', 'template.html')
FONTS = os.path.join(SKILL, 'template', 'fonts')

T = 1.12  # half period of the pendulum = one line per swing


def timings(n_lines, prompt):
    k = {}
    k['swEnd'] = (n_lines + 1) * T
    k['sp0'] = k['swEnd'] + 0.82
    k['sp1'] = k['sp0'] + 2.4
    k['sp2'] = k['sp1'] + 0.45
    k['st'] = k['sp2'] + 0.6
    k['chip0'] = k['st'] + 0.95
    k['chip1'] = k['st'] + 1.75
    k['leg1'] = k['st'] + 2.25
    k['q0'] = k['leg1'] + 1.0
    k['q1'] = k['q0'] + max(1.25, len(prompt) * 0.017)
    k['leg2'] = k['q1'] + 0.2
    k['bar0'] = k['leg2'] + 1.05
    k['bar1'] = k['bar0'] + 0.8
    k['done'] = k['bar1'] + 0.05
    k['en'] = k['done'] + 0.95
    k['d'] = round(k['en'] + 3.0, 2)
    return {a: round(b, 3) for a, b in k.items()}


def inline(text):
    """[word] = accent colour, {word} = second colour, *word* = italic serif accent."""
    t = html.escape(text)
    t = re.sub(r'\[(.+?)\]', r'<span class="o">\1</span>', t)
    t = re.sub(r'\{(.+?)\}', r'<span class="b">\1</span>', t)
    t = re.sub(r'\*(.+?)\*', r'<span class="serif o">\1</span>', t)
    return t


def line_html(i, L, out):
    rows = ''.join(f'<div>{inline(r)}</div>' for r in L['text'].split('|'))
    logo = ''
    lg = L.get('logo')
    if lg:
        if lg.get('image'):
            name = f'logo{i}' + os.path.splitext(lg['image'])[1]
            shutil.copy(lg['image'], os.path.join(out, name))
            inner = f'<img src="{name}" alt="">'
        else:
            st = f"background:{lg.get('bg', '#222')};color:{lg.get('fg', '#fff')};"
            if lg.get('border'):
                st += f"border:7px solid {lg['border']};"
            inner = f'<div class="ico" style="{st}">{html.escape(lg.get("text", ""))}</div>'
        mark = L.get('mark')
        if mark == 'check':
            inner += (f'<svg class="badge" viewBox="0 0 86 86"><circle id="bc{i}" cx="43" cy="43" r="40" fill="#22B35E" '
                      f'stroke="var(--paper)" stroke-width="5"/><path id="bk{i}" d="M24 44 L37 57 L62 30" fill="none" '
                      f'stroke="#fff" stroke-width="9" stroke-linecap="round" stroke-linejoin="round" pathLength="1" '
                      f'stroke-dasharray="1" stroke-dashoffset="1"/></svg>')
        elif mark == 'cross':
            inner += (f'<svg class="xmark" viewBox="0 0 224 224">'
                      f'<path id="xa{i}" d="M20 20 L204 204" stroke="#E5383B" stroke-width="22" stroke-linecap="round" pathLength="1" stroke-dasharray="1" stroke-dashoffset="1"/>'
                      f'<path id="xb{i}" d="M204 20 L20 204" stroke="#E5383B" stroke-width="22" stroke-linecap="round" pathLength="1" stroke-dasharray="1" stroke-dashoffset="1"/></svg>')
        logo = f'<div class="logo" id="lg{i}">{inner}</div>'
    return f'  <div id="l{i}" class="full line">{logo}{rows}</div>\n'


def step_title(s):
    a, _, b = s.partition('*')
    b = b.rstrip('*')
    return html.escape(a) + (f'<span class="serif">{html.escape(b)}</span>' if b else '')


def get_gsap(out):
    dst = os.path.join(out, 'gsap.min.js')
    if os.path.exists(dst):
        return
    tmp = os.path.join(out, '.gsap')
    os.makedirs(tmp, exist_ok=True)
    subprocess.run(['npm', 'pack', 'gsap@3.14.2'], cwd=tmp, check=True, capture_output=True)
    with tarfile.open(os.path.join(tmp, 'gsap-3.14.2.tgz')) as tf:
        f = tf.extractfile('package/dist/gsap.min.js')
        open(dst, 'wb').write(f.read())
    shutil.rmtree(tmp)


# ---------------- sound design ----------------
SR = 44100
rng = np.random.default_rng(7)


def tt(d):
    return np.arange(int(d * SR)) / SR


def bp(x, lo, hi):
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(len(x), 1 / SR)
    X[(f < lo) | (f > hi)] = 0
    return np.fft.irfft(X, len(x))


def whoosh(d, lo=300, hi=6000, peak=0.5):
    t = tt(d)
    n = bp(rng.standard_normal(len(t)), lo, hi)
    env = np.where(t < d * peak, (t / (d * peak)) ** 2, np.exp(-(t - d * peak) / (d * 0.18)))
    return n / np.abs(n).max() * env


def thump(f0=90, d=0.35, drop=40):
    t = tt(d)
    ph = 2 * np.pi * np.cumsum(f0 * np.exp(-t * drop / 10) + 30) / SR
    return np.sin(ph) * np.exp(-t * 14)


def click(d=0.012):
    t = tt(d)
    n = rng.standard_normal(len(t)) * np.exp(-t * 600)
    n = bp(np.pad(n, (0, 400)), 2000, 9000)[:len(t)]
    return n / np.abs(n).max()


def bell(fs, d=1.4, dec=3.0):
    t = tt(d)
    s = sum(np.sin(2 * np.pi * f * t) * np.exp(-t * dec * (1 + k * 0.4)) / (1 + k)
            + 0.3 * np.sin(2 * np.pi * f * 2.01 * t) * np.exp(-t * dec * 3) for k, f in enumerate(fs))
    s *= np.minimum(1, t / 0.004)
    return s / np.abs(s).max()


def pop(f=420, d=0.1):
    t = tt(d)
    return np.sin(2 * np.pi * (f * t + 5000 * t * t)) * np.exp(-t * 55) * np.minimum(1, t / 0.003)


def sweep(f0, f1, d):
    t = tt(d)
    f = f0 * (f1 / f0) ** (t / d)
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * (0.6 + 0.4 * np.sin(2 * np.pi * 14 * t))
    return s * np.minimum(1, t / 0.05) * np.minimum(1, (d - t) / 0.05)


def buzz(d=0.16):
    t = tt(d)
    s = np.sign(np.sin(2 * np.pi * 140 * t)) * 0.5 + np.sin(2 * np.pi * 70 * t) * 0.5
    s = np.convolve(s, np.ones(8) / 8, 'same')
    return s * np.exp(-t * 12) * np.minimum(1, t / 0.004)


def sound(cfg, k, path):
    D = k['d']
    out = np.zeros(int(SR * D) + SR)

    def add(sig, t, g=1.0):
        i = int(t * SR)
        n = min(len(sig), len(out) - i)
        out[i:i + n] += sig[:n] * g

    nl = len(cfg['lines'])
    for p in range(nl + 1):  # each swing: whoosh + thump as the ball crosses the line
        mid = p * T + T / 2
        big = p == nl
        add(whoosh(0.8 if big else 0.62, 200, 7000, 0.55), mid - 0.34, 0.7 if big else 0.55)
        add(thump(60 if big else 85, 0.9 if big else 0.4, 40), mid - 0.02, 1.1 if big else 0.9)
        add(click(0.02), mid - 0.02, 0.35)
    for i, L in enumerate(cfg['lines']):
        m = (i + 0.5) * T
        if L.get('mark') == 'check':
            add(pop(600, 0.08), m + 0.3, 0.35)
            add(bell([1047, 1568], 0.6, 6), m + 0.47, 0.32)
        if L.get('mark') == 'cross':
            for x in (m + 0.3, m + 0.5):
                add(buzz(), x, 0.45)
                add(whoosh(0.15, 1500, 8000, 0.3), x - 0.02, 0.15)
    t = tt(k['sp2'] - k['swEnd'] + 0.4)  # low drone in the dark
    dl = len(t) / SR
    env = np.minimum(1, t / 0.4) * np.minimum(1, (dl - t) / 0.6)
    add((np.sin(2 * np.pi * 48 * t) + 0.5 * np.sin(2 * np.pi * 72 * t)) * env, k['swEnd'] - 0.08, 0.35)
    nz = bp(rng.standard_normal(len(t)), 80, 400)
    add(nz / np.abs(nz).max() * env, k['swEnd'] - 0.08, 0.12)
    add(sweep(260, 1300, 0.7) * np.linspace(1, 0.3, int(0.7 * SR)), k['swEnd'] + 0.12, 0.18)
    for x in (k['sp0'] + 0.2, k['sp0'] + 1.0, k['sp0'] + 1.7):
        add(whoosh(0.7, 150, 2500, 0.5), x, 0.28)
    add(bell([660, 830, 990], 2.0, 2.2), k['sp2'] - 0.03, 0.45)
    st = k['st']
    h = len(''.join(cfg['how']))
    for i in range(h):
        add(click(), st + 0.1 + 0.65 * i / h, 0.22)
    for a in (st, k['leg1'], k['leg2']):
        add(whoosh(0.65, 500, 5000, 0.5), a, 0.25)
    for a in (st + 0.55, k['leg1'] + 0.55, k['leg2'] + 0.55):
        add(pop(380, 0.12), a, 0.55)
        for i in range(7):
            add(click(0.008), a + 0.05 + 0.25 * i / 7, 0.12)
    c = cfg['chip']
    for i in range(len(c)):
        add(click(), k['chip0'] + (k['chip1'] - k['chip0']) * i / len(c), 0.2)
    add(bell([1320, 1760], 0.5, 8), k['chip1'] + 0.05, 0.25)
    q = cfg['prompt']
    for i in range(0, len(q), 2):
        add(click(), k['q0'] + (k['q1'] - k['q0']) * i / len(q), 0.2)
    add(sweep(400, 1700, 0.8), k['bar0'], 0.13)
    add(bell([1047, 1319, 1568], 0.9, 5), k['done'], 0.33)
    en = k['en']
    add(whoosh(0.5, 300, 6000, 0.6), en - 0.4, 0.35)
    for i in range(len(''.join(cfg['name']))):
        add(click(), en + 0.15 + 0.5 * i / len(''.join(cfg['name'])), 0.22)
    add(whoosh(0.4, 300, 4000, 0.7), en + 0.6, 0.2)
    land = en + 0.6 + 0.65 * 0.55
    add(thump(110, 0.3, 30), land, 0.8)
    add(pop(300, 0.12), land, 0.4)
    add(pop(520, 0.1), en + 1.35, 0.6)
    add(bell([523, 659, 784, 1047], 2.2, 1.6), en + 1.38, 0.4)
    add(click(0.015), en + 1.65, 0.3)
    t = tt(2.0)
    pad = sum(np.sin(2 * np.pi * f * t) for f in (130.8, 196, 261.6)) * np.minimum(1, t / 0.5) * np.minimum(1, (2.0 - t) / 0.8)
    add(pad / 3, en + 1.0, 0.12)

    out = out[:int(SR * D)]
    out = out / np.abs(out).max() * 0.89
    st2 = (np.stack([out, out], 1) * 32767).astype('<i2')
    w = wave.open(path, 'wb')
    w.setnchannels(2)
    w.setsampwidth(2)
    w.setframerate(SR)
    w.writeframes(st2.tobytes())
    w.close()


def main():
    cfg_path, out = sys.argv[1], sys.argv[2]
    cfg = json.load(open(cfg_path))
    base = os.path.dirname(os.path.abspath(cfg_path))
    for L in cfg['lines']:
        if L.get('logo', {}).get('image') and not os.path.isabs(L['logo']['image']):
            L['logo']['image'] = os.path.join(base, L['logo']['image'])
    os.makedirs(out, exist_ok=True)
    shutil.copytree(FONTS, os.path.join(out, 'fonts'), dirs_exist_ok=True)
    get_gsap(out)

    k = timings(len(cfg['lines']), cfg['prompt'])
    col = cfg.get('colors', {})
    name = cfg['name']
    js = {'T': T, 'nLines': len(cfg['lines']), 'k': k, 'how': cfg.get('how', ['how it ', 'works']),
          'chip': cfg['chip'], 'prompt': cfg['prompt'], 'name': name,
          'lines': [{'logo': bool(L.get('logo')), 'mark': L.get('mark')} for L in cfg['lines']]}
    rep = {
        '__ACCENT__': col.get('accent', '#D97757'), '__ALT__': col.get('alt', '#2F3FD8'),
        '__INK__': col.get('ink', '#151515'), '__PAPER__': col.get('paper', '#E8E2CF'),
        '__DARK__': col.get('dark', '#14151A'),
        '__D__': str(k['d']), '__HANDLE_AT__': html.escape('@' + cfg['handle']),
        '__HANDLE__': html.escape(cfg['handle']),
        '__LINES__': ''.join(line_html(i, L, out) for i, L in enumerate(cfg['lines'])),
        '__SPOT1__': inline(cfg['spotlight'][0]), '__SPOT2__': inline(cfg['spotlight'][1]),
        '__S0__': step_title(cfg['steps'][0]), '__S1__': step_title(cfg['steps'][1]),
        '__S2__': step_title(cfg['steps'][2]), '__FILE__': html.escape(cfg.get('file', 'reel.mp4')),
        '__KEYWORD__': html.escape(cfg['keyword']), '__PILL_TAIL__': html.escape(cfg.get('pill_tail', 'for the skill')),
        '__FOLLOW__': html.escape(cfg.get('follow', 'Follow for more AI builds')),
        '__CFGJS__': json.dumps(js),
    }
    s = open(TEMPLATE).read()
    for a, b in rep.items():
        s = s.replace(a, b)
    n = len(''.join(name))
    if n > 10:  # keep the end-card name inside the safe zone
        s = s.replace('font-size:140px;letter-spacing:-0.035em', f'font-size:{int(140 * 10 / n)}px;letter-spacing:-0.035em')
        s = s.replace('#name .serif{font-size:170px', f'#name .serif{{font-size:{int(170 * 10 / n)}px')
    open(os.path.join(out, 'index.html'), 'w').write(s)
    sound(cfg, k, os.path.join(out, 'sfx.wav'))
    print(f'built {out}: {k["d"]} s')


if __name__ == '__main__':
    main()
