---
name: swing-reel
description: Makes a vertical 9:16 motion-graphics reel with no filming - a swinging ball knocks bold text in line by line, a spotlight reveal, a "how it works" step timeline and a comment-keyword end card, with sound on every move. Use when someone asks for a swing reel, a swinging ball reel, a kinetic text reel, or a reel made only from text and graphics.
---

# Swing reel

Builds a ~19 second 1080x1920 reel entirely in code, no camera, no editor:

1. **Swing lines** (2 to 5): a pendulum ball swings across the screen and wipes each new line of bold text in. A line can have a logo above it that pops in, with a green check or a red cross drawn on it.
2. **Dark wipe + spotlight**: the last swing pulls a dark panel over the screen, the ball floats up and shines a spotlight cone that sways over one big line, then the light opens up.
3. **How it works**: the ball rolls down a timeline through 3 steps (a terminal chip that types, a prompt box that types, a render bar that fills to 100%).
4. **End card**: the creator's name types in, the ball drops onto it, and a pill says `comment "KEYWORD" for the skill`.

Every swing, pop, check, cross, keystroke and the render bar has its own sound (generated, no music, no licensing).

## What to ask the user

Ask in one short message, and offer to draft anything they don't have:
- The lines, short and punchy (2 to 4 words per row, 2 rows per line). Example: "Claude made this reel." / "Without After Effects." / "Just one skill."
- The spotlight line (two parts: a bold top and a big italic word). Example: "You can" + "steal it."
- The 3 steps (default: Install the skill / Describe your idea / Render the reel) and the prompt text shown typing in step 2.
- Their handle, the comment keyword and the CTA text.
- Logos for any line (ask them to upload the image, PNG or SVG). Simple app icons like "Ae" can be drawn instead of uploaded (see config).
- Brand colors (optional; the default is a warm cream with orange accent).

If they just say "make me one", draft all of it from their topic and show the text before rendering.

## How to build it

All paths are relative to this skill's folder.

1. **Set up** (once per machine): Node 18+ and Python 3 with numpy (`pip install numpy`). Hyperframes renders HTML to MP4 with headless Chrome:
   ```
   npx -y hyperframes init my-reel --non-interactive --resolution portrait --skip-transcribe
   ```
   If Chrome is missing, run `npx hyperframes browser ensure` once (`npx hyperframes doctor` checks the rest).
2. **Write the config.** Copy `config.example.json` next to the user's files and fill it in. Text markup:
   - `|` starts a new row
   - `[word]` = accent color, `{word}` = second color, `*word*` = italic serif accent
   - steps use `*...*` for the italic part, e.g. `"Install *the skill*"`
   - `logo`: `{"image": "file.png"}` (path relative to the config) or a drawn icon `{"text": "Ae", "bg": "#00005B", "fg": "#9999FF", "border": "#9999FF"}`
   - `mark`: `"check"` (green check draws on) or `"cross"` (red X draws over), or leave it out
   - `name`: two parts, the second shown in italic accent (e.g. `["shedoes", "ai"]`)
3. **Build** into the project folder (writes `index.html`, fonts, logos, `gsap.min.js` and `sfx.wav`):
   ```
   python3 scripts/build.py config.json my-reel
   ```
4. **Check frames before rendering** (fast):
   ```
   cd my-reel && npx hyperframes snapshot --at 1,2.2,5,7,8.4,13,15.4,18.9 --no-end -o ../snaps .
   ```
   Look at the contact sheet: text inside the safe zone, nothing cut off, logos visible.
5. **Render the preview** (about 40 s), sound included:
   ```
   npx hyperframes render -q standard -o ../preview-v1.mp4 .
   ```
   Send it to the user. Number every revision (v1, v2, v3).
6. **Final**, only after the user approves: `npx hyperframes render --resolution portrait-4k -q delivery -o ../final-4k.mp4 .`

## Rules

- **Safe zone**: everything stays inside x 60..960, y 160..1440 of 1080x1920 (clear of the TikTok/Instagram buttons and caption). The template already does this and shrinks long lines automatically; still check the snapshot.
- Keep lines short. More than ~14 characters per row gets small.
- The timing is automatic: one line per swing (1.12 s), then the spotlight, steps and end card. More lines make the reel longer (about +1.1 s per line).
- Edits are config edits: change the JSON, rebuild, re-render. Layout tweaks (heights, sizes, colors) live in `template/template.html`; the step timeline position is `#hiw{top}` and `const NY=[...]`.
- No em dashes in on-screen text.
- Fonts (Inter Tight, Instrument Serif, JetBrains Mono) are bundled under the SIL Open Font License.
